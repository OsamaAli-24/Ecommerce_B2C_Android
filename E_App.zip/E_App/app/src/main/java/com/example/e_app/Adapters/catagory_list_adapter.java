package com.example.e_app.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_app.R;
import com.example.e_app.models.catagory_list_model;
import com.example.e_app.models.catagory_model;

import java.util.ArrayList;


public class catagory_list_adapter extends RecyclerView.Adapter<catagory_list_adapter.viewHolder> {

    public catagory_list_adapter(ArrayList<catagory_list_model> list, Context context) {
        this.list = list;
        this.context = context;
    }

    ArrayList<catagory_list_model>list;
    Context context;


    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.catagory_cardview,null);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) {
        catagory_list_model model=list.get(position);
        holder.textView.setText(model.getText());
        holder.imageView.setImageResource(model.getPic());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textView;




        public viewHolder(@NonNull View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.phone_image);
            textView =itemView.findViewById(R.id.phone_title);
        }
    }
}
