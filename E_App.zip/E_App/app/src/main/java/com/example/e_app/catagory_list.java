package com.example.e_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.Menu;

import com.example.e_app.Adapters.catagory_adapter;
import com.example.e_app.Adapters.catagory_list_adapter;
import com.example.e_app.models.catagory_list_model;
import com.example.e_app.models.catagory_model;

import java.util.ArrayList;

public class catagory_list extends AppCompatActivity {
    RecyclerView recyclerView;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catagory_list);
        recyclerView=findViewById(R.id.catagory_list_recycler);

        toolbar=findViewById(R.id.home_toolbar);
        setSupportActionBar(toolbar);



        ArrayList<catagory_list_model> list1 = new ArrayList<>();
        list1.add(new catagory_list_model(R.drawable.banner1,"shoes"));
        list1.add(new catagory_list_model(R.drawable.banner1,"bags"));
        list1.add(new catagory_list_model(R.drawable.banner1,"clothes"));
        list1.add(new catagory_list_model(R.drawable.banner1,"shoes"));
        list1.add(new catagory_list_model(R.drawable.banner1,"bags"));
        list1.add(new catagory_list_model(R.drawable.banner1,"clothes"));


        catagory_list_adapter adapter = new catagory_list_adapter(list1,this);
        recyclerView.setAdapter(adapter);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(layoutManager);



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }
}