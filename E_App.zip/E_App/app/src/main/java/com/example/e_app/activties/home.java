package com.example.e_app.activties;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.example.e_app.Adapters.NewProduct_adapter;
import com.example.e_app.Adapters.PopularProduct_adapter;
import com.example.e_app.Adapters.catagory_adapter;
import com.example.e_app.R;
import com.example.e_app.catagory_list;
import com.example.e_app.models.NewProdeuct_model;
import com.example.e_app.models.PopularProduct_model;
import com.example.e_app.models.catagory_model;

import java.util.ArrayList;
import java.util.List;

public class home extends AppCompatActivity {
    Toolbar toolbar;
    RecyclerView recyclerView1;
    RecyclerView recyclerView2;
    RecyclerView recyclerView3;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        toolbar=findViewById(R.id.home_toolbar);
        setSupportActionBar(toolbar);

      recyclerView1=findViewById(R.id.rec_category);
        recyclerView2=findViewById(R.id.new_product_rec);
        recyclerView3=findViewById(R.id.popular_rec);

      ArrayList<catagory_model> list1 = new ArrayList<>();
      list1.add(new catagory_model(R.drawable.banner1,"shoes"));
        list1.add(new catagory_model(R.drawable.banner1,"bags"));
        list1.add(new catagory_model(R.drawable.banner1,"clothes"));

        ArrayList<NewProdeuct_model> list2 = new ArrayList<>();
        list2.add(new NewProdeuct_model(R.drawable.banner1,"shoes"));
        list2.add(new NewProdeuct_model(R.drawable.banner1,"bags"));
        list2.add(new NewProdeuct_model(R.drawable.banner1,"clothes"));

        ArrayList<PopularProduct_model> list3 = new ArrayList<>();
        list3.add(new PopularProduct_model(R.drawable.banner1,"shoes"));
        list3.add(new PopularProduct_model(R.drawable.banner1,"bags"));
        list3.add(new PopularProduct_model(R.drawable.banner1,"clothes"));

        catagory_adapter adapter = new catagory_adapter(list1,this);
        recyclerView1.setAdapter(adapter);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        recyclerView1.setLayoutManager(layoutManager);

        NewProduct_adapter adapter1 = new NewProduct_adapter(list2,this);
        recyclerView2.setAdapter(adapter1);
        LinearLayoutManager layoutManager1=new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        recyclerView2.setLayoutManager(layoutManager1);

        PopularProduct_adapter adapter2 = new PopularProduct_adapter(list3,this);
        recyclerView3.setAdapter(adapter2);
        LinearLayoutManager layoutManager2=new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        recyclerView3.setLayoutManager(layoutManager2);


        ImageSlider imageSlider = findViewById(R.id.image_slider);
        List<SlideModel> slideModels=new ArrayList<>();

        slideModels.add(new SlideModel(R.drawable.banner1,"Discount on shoes", ScaleTypes.CENTER_CROP));
        slideModels.add(new SlideModel(R.drawable.banner1,"Discount on glasses", ScaleTypes.CENTER_CROP));
        slideModels.add(new SlideModel(R.drawable.banner1,"Discount on handbags", ScaleTypes.CENTER_CROP));

        imageSlider.setImageList(slideModels);

    }

    @Override
   public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    public void seeall(View view){
        Intent intent= new Intent(this, catagory_list.class);
        startActivity(intent);


    }
    public void seeall1(View view){
        Intent intent= new Intent(this, signup.class);
        startActivity(intent);


    }
    public void seeall2(View view){
        Intent intent= new Intent(this, signup.class);
        startActivity(intent);


    }
}